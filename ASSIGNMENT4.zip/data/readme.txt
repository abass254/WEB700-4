Just a little note to record changes
Preparing for vercel moving all files to root to check operation